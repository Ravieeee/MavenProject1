package testCases;

import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import base.TestBase;
import page_Objects.LoginPage;

public class LoginPageTest extends TestBase {
	
	public static LoginPage login; 
	public LoginPageTest()
	{
		super();
	}
	
	@BeforeMethod
	public static void setup()
	{
		initialization();
		login=new LoginPage();
	}
	
	@Test
	public void inputLoginTest()
	{
	
//		String title=login.inputLogin();
	//	Assert.assertEquals(title, "USER LOGIN");
	}
	
	@Test (dataProvider="getdata")
	public void inputTest(String uname, String pword)
	{
	
		login.inputLogin(uname, pword);
//		Assert.assertEquals(title, "USER LOGIN");
		Assert.fail();
	}
	
	@DataProvider
	public static Object[][] getdata()
	{
		
		
		
		return null;
		

	}
	
	
	@AfterMethod
	public void tearDown() throws InterruptedException
	{
		Thread.sleep(5000);
		driver.quit();
	}
	

}
