package testCases;

import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import base.TestBase;
import page_Objects.LoginPage;
import util.TestUtil;

public class LoginPageTest extends TestBase {
	
	public static LoginPage login; 
	public static TestUtil testUtil;
	public String alertMessage="ither you are not Authorized or Your Username/Password is invalid !!!";

	public LoginPageTest()
	{
		super();
	}
	
	@BeforeMethod
	public static void setup()
	{
		initialization();
		login=new LoginPage();
		testUtil=new TestUtil();		
	}
	
	
	@Test (dataProvider="getdata")
	public void inputTest(String uname, String pword) throws InterruptedException
	{
		login.inputLogin(uname, pword);
		
		try {		
		if(testUtil.isAlertDisplayed()==true)
			{			
				String alertText= testUtil.getAlertText();
				Assert.assertEquals(alertText, alertMessage);
			}
		else
		{
			Assert.fail();
		}
		}
		catch(Exception ex)
			{
				Assert.fail();
			}
		}
	
	
	
	
	
	
	@DataProvider(name="getdata")
	public static Object[][] getdata()
	{
		return new Object[][]
				{
				{ "Guru99", "jui" },
				//{ "Krishna", "UK" },			 
				};
	}
	
	@AfterMethod
	public void tearDown() throws InterruptedException
	{
		Thread.sleep(5000);
		driver.quit();
	}
	

}
