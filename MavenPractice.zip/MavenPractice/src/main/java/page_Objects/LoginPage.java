package page_Objects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import base.TestBase;

public class LoginPage extends TestBase {
	;
	//String loginBtn="//input[@name='btnLogin']";
	//String resetBtn="//input[@name='btnReset']";
	
//By xpath = By.xpath("//input[@name='btnReset']");

		@FindBy(xpath="//input[@id='username']")
		WebElement username;
		
		
		@FindBy(xpath="//input[@id='upassword']")
		WebElement password;
		
		@FindBy(xpath="//button[@type='submit']")
		WebElement loginBtn;
			

		public LoginPage()
		{
			PageFactory.initElements(driver, this);
		}
		
		
		
	public void inputLogin(String uname, String pword)
	{
		username.sendKeys(uname);
		System.out.println("Ping1");
		password.sendKeys(pword);
		System.out.println("Ping2");
		loginBtn.click();
		
		//return new ModuleSelectionPage();
		
//	return	driver.getTitle();
		
		
	}
}
