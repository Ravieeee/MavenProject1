package page_Objects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import base.TestBase;

public class LoginPage extends TestBase {
		
	//String username="//input[@name='uid']";
	//String password="//input[@name='password']";
	//String loginBtn="//input[@name='btnLogin']";
	//String resetBtn="//input[@name='btnReset']";
	
//By xpath = By.xpath("//input[@name='btnReset']");

		@FindBy(xpath="//input[@name='uid']")
		WebElement username;
		
		@FindBy(xpath="//input[@name='btnReset']")
		WebElement resetBtn;
		
		/*@FindBy(xpath="//input[@name='btnReset']")
		WebElement resetBtn;*/
			

		public LoginPage()
		{
			PageFactory.initElements(driver, this);
		}
		
		
		
	public ModuleSelectionPage inputLogin(String uname, String pword)
	{
		username.sendKeys(uname);
		username.sendKeys(pword);
		resetBtn.click();
		
		return new ModuleSelectionPage();
		
//	return	driver.getTitle();
		
		
	}
}
