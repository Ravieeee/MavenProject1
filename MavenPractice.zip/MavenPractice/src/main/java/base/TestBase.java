package base;

import java.io.FileInputStream;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxBinary;
import org.openqa.selenium.firefox.FirefoxDriver;

public class TestBase {
	
	public static WebDriver driver;
	public static Properties prop;
	
	public TestBase() {
	try {
		
		prop=new Properties();
		FileInputStream fis=new FileInputStream("C:\\Users\\user1\\eclipse-workspace\\MavenPractice\\src\\main\\java\\configDetails\\config.Properties");
		prop.load(fis);
	}
	
	catch (Exception ex)
	{
		ex.printStackTrace();
	}
}
	public static void initialization()
	{
		String propValue=prop.getProperty("browser");	
		//System.out.println("PropValue:"+propValue);
		
		if(propValue.equals("chrome"))
		{
			System.setProperty("webdriver.chrome.driver","E:\\Selenium files\\chromedriver_win32\\chromedriver.exe");
		    driver= new ChromeDriver();		    
		}
		else if(propValue.equals("FF"))
		{
			System.setProperty("webdriver.gecko.driver","E:\\Selenium files\\geckodriver.exe" );
			driver=new FirefoxDriver();			
		}
		driver.manage().window().maximize();		
		
		driver.get(prop.getProperty("url"));
		driver.manage().timeouts().implicitlyWait(3000, TimeUnit.SECONDS);
		
	}
}