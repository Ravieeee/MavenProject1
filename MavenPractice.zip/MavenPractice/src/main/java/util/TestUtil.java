package util;

import org.openqa.selenium.Alert;
import org.openqa.selenium.NoAlertPresentException;

import base.TestBase;

public class TestUtil  extends TestBase{
	
	public TestUtil() {
		super();
	}
	
	
public boolean isAlertDisplayed() throws InterruptedException
{
	try{ 
        Alert alert = driver.switchTo().alert();
        return true;     
    } 
    catch (NoAlertPresentException ex) {
        System.err.println("Status: No Alert Present!");
        return false; 
    } 
}
public String getAlertText()
{
	 
        Alert alert = driver.switchTo().alert();
        String alertText=alert.getText();
        alert.accept();
        return alertText;
        
}
	
	public static Object[][] getdata1(String filename)
	{
		
		ExcelReader excel = new ExcelReader(System.getProperty("user.dir") + "\\src\\test\\resources\\ExcelData\\Testdata.xlsx");

		int Totalrows = excel.getRowCount(filename);
		
		int Totalcells = excel.getColumnCount(filename);
		
		Object[][] data = new Object[Totalrows-1][Totalcells];
		
		for(int rows=2; rows<=Totalrows; rows++) 
		{
			for(int cells=0; cells<Totalcells; cells++)
			{
				data[rows-2][cells] = excel.getCellData(filename, cells, rows);
				
			}
			
		}
		return data;
	}

}
