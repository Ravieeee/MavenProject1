package util;

public class TestUtil {
	
	

	
	public static Object[][] getdata1(String filename)
	{
		
		ExcelReader excel = new ExcelReader(System.getProperty("user.dir") + "\\src\\test\\resources\\ExcelData\\Testdata.xlsx");

		int Totalrows = excel.getRowCount(filename);
		
		int Totalcells = excel.getColumnCount(filename);
		
		Object[][] data = new Object[Totalrows-1][Totalcells];
		
		for(int rows=2; rows<=Totalrows; rows++) 
		{
			for(int cells=0; cells<Totalcells; cells++)
			{
				data[rows-2][cells] = excel.getCellData(filename, cells, rows);
				
			}
			
		}
		return data;
	}

}
